
import React, { useState } from 'react';
import { CertificateDetails } from './types';
import CertificateView from './components/CertificateView';
import { Printer, Download, Search } from 'lucide-react';

const App: React.FC = () => {
  // Pre-filled with user's requested details
  const [details] = useState<CertificateDetails>({
    name: "ANURAN MAJUMDER",
    serialNo: "2064",
    batchNo: "49",
    registrationNo: "38383",
    courseName: "Diploma in Tool and Die Making",
    courseDetails: "(Approved by AICTE. Equivalent to Diploma in Mechanical Engineering for the purpose of employment)",
    examinationDate: "July, 2022",
    placedIn: "Second Division"
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="flex flex-col items-center py-8 px-4 md:py-12">
      {/* Search Header (Mimicking a portal feel) */}
      <div className="w-full max-w-4xl mb-8 no-print">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-xl font-semibold text-gray-800 flex items-center gap-2">
                <Search className="w-5 h-5 text-blue-600" />
                Certificate Verification Portal
              </h1>
              <p className="text-sm text-gray-500">Official verification record for MSME Tool Room - Kolkata</p>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={handlePrint}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded transition-colors text-sm font-medium"
              >
                <Printer className="w-4 h-4" />
                Print Record
              </button>
              <button 
                onClick={handlePrint}
                className="flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded transition-colors text-sm font-medium"
              >
                <Download className="w-4 h-4" />
                Download PDF
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* The Certificate UI */}
      <div className="w-full max-w-4xl certificate-container bg-white shadow-sm border border-gray-100 p-4 md:p-8 min-h-[600px]">
        <CertificateView details={details} />
      </div>

      <footer className="mt-12 text-center text-gray-400 text-xs no-print pb-8">
        <p>&copy; {new Date().getFullYear()} MSME Tool Room - Kolkata. All rights reserved.</p>
        <p className="mt-1">Powered by CTTC Verification System</p>
      </footer>
    </div>
  );
};

export default App;
