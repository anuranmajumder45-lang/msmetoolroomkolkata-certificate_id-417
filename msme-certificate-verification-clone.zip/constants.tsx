
import React from 'react';
import { ShieldCheck } from 'lucide-react';

export const APP_TITLE = "MSME Certificate Verification";
export const APP_ICON = <ShieldCheck className="w-6 h-6 text-blue-600" />;
