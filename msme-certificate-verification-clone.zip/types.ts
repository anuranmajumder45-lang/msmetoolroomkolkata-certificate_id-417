
export interface CertificateDetails {
  name: string;
  serialNo: string;
  batchNo: string;
  registrationNo: string;
  courseName: string;
  courseDetails: string;
  examinationDate: string;
  placedIn: string;
}
