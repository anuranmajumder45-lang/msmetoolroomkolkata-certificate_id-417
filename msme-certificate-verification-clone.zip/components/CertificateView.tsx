
import React from 'react';
import { CertificateDetails } from '../types';

interface Props {
  details: CertificateDetails;
}

const CertificateView: React.FC<Props> = ({ details }) => {
  return (
    <div className="font-sans text-[#333]">
      {/* Header */}
      <div className="border-b-2 border-gray-200 pb-4 mb-4">
        <h2 className="text-2xl font-bold text-center tracking-wide uppercase">
          MSME TOOL ROOM - KOLKATA
        </h2>
      </div>

      {/* Verification Table */}
      <div className="w-full">
        <table className="w-full border-collapse">
          <tbody>
            <tr className="border-b border-gray-200">
              <td className="py-3 px-2 font-medium w-1/3 text-sm md:text-base">Name:</td>
              <td className="py-3 px-2 text-sm md:text-base uppercase">{details.name}</td>
            </tr>
            <tr className="border-b border-gray-200">
              <td className="py-3 px-2 font-medium text-sm md:text-base">Serial No:</td>
              <td className="py-3 px-2 text-sm md:text-base">{details.serialNo}</td>
            </tr>
            <tr className="border-b border-gray-200">
              <td className="py-3 px-2 font-medium text-sm md:text-base">Batch No:</td>
              <td className="py-3 px-2 text-sm md:text-base">{details.batchNo}</td>
            </tr>
            <tr className="border-b border-gray-200">
              <td className="py-3 px-2 font-medium text-sm md:text-base">Registration No:</td>
              <td className="py-3 px-2 text-sm md:text-base">{details.registrationNo}</td>
            </tr>
            <tr className="border-b border-gray-200">
              <td className="py-3 px-2 font-medium align-top text-sm md:text-base">Course Name:</td>
              <td className="py-3 px-2 text-sm md:text-base leading-relaxed">
                <div className="font-semibold italic">{details.courseName}</div>
                <div className="text-xs md:text-sm text-gray-600 mt-1">
                  {details.courseDetails}
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Footer Details */}
      <div className="mt-8 space-y-4 text-center">
        <div className="flex flex-col md:flex-row items-center justify-center gap-2">
          <span className="text-[#008080] font-semibold text-sm md:text-base">Examination Date:</span>
          <span className="font-bold text-sm md:text-base">{details.examinationDate}</span>
        </div>
        <div className="flex flex-col md:flex-row items-center justify-center gap-2">
          <span className="text-[#008080] font-semibold text-sm md:text-base">Placed In:</span>
          <span className="font-bold text-sm md:text-base">{details.placedIn}</span>
        </div>
      </div>

      {/* Optional Placeholder for Watermark or Seal (Invisible in digital) */}
      <div className="mt-16 flex justify-end opacity-20 pointer-events-none select-none no-print">
        <div className="border-4 border-gray-300 rounded-full w-24 h-24 flex items-center justify-center text-[10px] text-center font-bold rotate-12">
          MSME <br/> VERIFIED
        </div>
      </div>
    </div>
  );
};

export default CertificateView;
